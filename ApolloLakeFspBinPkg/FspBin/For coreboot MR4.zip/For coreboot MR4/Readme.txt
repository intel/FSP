To Integrate FSP into coreboot MR4:

1. Go to folder: intel/fsp/soc/apllake/bin/

2. Copy and rename FSP to 
	Fsp.fd
	Fsp.bsf

3. Copy FSP header file to folder: intel/fsp/soc/apllake/inc/
